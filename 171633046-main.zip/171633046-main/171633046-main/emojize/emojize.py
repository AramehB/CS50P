import emoji
print(emoji.emojize(input("Input: ").strip(), language='alias'))
