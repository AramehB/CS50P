print(input("Goodbye: "))
