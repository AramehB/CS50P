print(input("Hello: "))
