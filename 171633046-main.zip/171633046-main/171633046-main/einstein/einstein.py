# E = mc^2

energy = (int(input("m: "))*(300000000**2))
print("e:", energy)
