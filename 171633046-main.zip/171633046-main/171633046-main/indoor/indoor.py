print(input("What did you say?: ").lower())
