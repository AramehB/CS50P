print(input("What did you say?: " ).replace(" ", "..."))
